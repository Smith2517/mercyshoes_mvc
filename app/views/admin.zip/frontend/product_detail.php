
<?php include __DIR__ . '/partials/product_detail_content.php'; ?>

